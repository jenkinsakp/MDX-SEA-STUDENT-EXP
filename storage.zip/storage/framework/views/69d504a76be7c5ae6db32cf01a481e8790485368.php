<?php $__env->startSection('title','E-SHOP || HOME PAGE'); ?>

<div style="text-align: center">
    <button wire:click="increment">+</button>
    <h1><?php echo e(@$count); ?></h1>
</div>


<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\JENKINS\Documents\IP\Ecommerce\resources\views/livewire/counter.blade.php ENDPATH**/ ?>