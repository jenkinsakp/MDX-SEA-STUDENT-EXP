

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php /**PATH C:\Users\JENKINS\Documents\IP\Ecommerce\resources\views/auth/register.blade.php ENDPATH**/ ?>